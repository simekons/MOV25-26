package com.example.engine;

public interface IImage
{
    // Getter de la anchura de una imagen
    int getWidth();
    // Getter de la altura de una imagen
    int getHeight();
}
