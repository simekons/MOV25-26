package com.example.engine;

public interface IFont
{
    // Getter del tamaño de la fuente
    int getSize();
    // Getter del estilo de la fuente (negrita)
    boolean isBold();
}
