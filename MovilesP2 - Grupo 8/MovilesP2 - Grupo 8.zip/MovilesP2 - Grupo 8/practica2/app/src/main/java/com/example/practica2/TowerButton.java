package com.example.practica2;

import android.media.Image;

import com.example.androidengine.AndroidFont;
import com.example.androidengine.AndroidGraphics;
import com.example.androidengine.AndroidImage;
import com.example.engine.IFont;
import com.example.engine.IGraphics;
import com.example.engine.IImage;

/**
 * TowerButton implementa los botones de las torres.
 */
public class TowerButton {

    // Gráficos.
    private AndroidGraphics iGraphics;

    // Fuente.
    private AndroidFont iFont;

    // Texto.
    private String text;

    // Coordenadas, ancho y alto.
    private float x, y, width, height;

    private AndroidImage img;

    // Variables.
    private int buttonColor, textColor, cost;

    // ¿Está seleccionado? (sí/no).
    private boolean selected;

    // Tipo de torre.
    private TowerType tipo;

    /**
     * CONSTRUCTORA.
     * @param graphics
     * @param font
     * @param x
     * @param y
     * @param width
     * @param height
     * @param cost
     * @param tipo
     * @param buttonColor
     * @param textColor
     * @param img
     */
    public TowerButton(AndroidGraphics graphics, AndroidFont font,
                       float x, float y, float width, float height,
                       int cost, TowerType tipo, int buttonColor, int textColor, AndroidImage img) {
        this.iGraphics = graphics;
        this.iFont = font;
        this.cost = cost;
        this.tipo = tipo;
        this.text = "" + cost;
        this.x = x - (width / 2);
        this.y = y - (height / 2);
        this.width = width;
        this.height = height;
        this.buttonColor = buttonColor;
        this.textColor = textColor;
        this.selected = false;
        this.img = img;
    }

    /**
     * Método de RENDERIZADO.
     */
    public void render() {
        iGraphics.setColor(buttonColor);
        iGraphics.fillRoundRectangle(x, y, width, height, 5);


        float textHeight = height * 0.25f;
        float imageHeight = height - textHeight;


        float marginX = width * 0.1f;
        float marginY = imageHeight * 0.1f;


        float availableWidth = width - (2 * marginX);
        float availableHeight = imageHeight - (2 * marginY);


        float drawX = x + (width / 2);
        float drawY = y + (imageHeight / 2);

        if (img != null)
            iGraphics.drawImage(img, (int) (x +  width/2), (int) (y + height/2 - 7), (int) (width-15), (int) (height-15));
        else
            switch (tipo) {
                case Rayo:
                    iGraphics.setColor(0xFF000000);
                    float halfBase = availableWidth / 2;
                    float halfHeight = availableHeight / 2;

                    float x1 = drawX;
                    float y1 = drawY - halfHeight;
                    float x2 = drawX - halfBase;
                    float y2 = drawY + halfHeight;
                    float x3 = drawX + halfBase;
                    float y3 = drawY + halfHeight;

                    iGraphics.fillTriangle(x1, y1, x2, y2, x3, y3);
                    break;
                case Hielo:
                    iGraphics.setColor(0xFF88539E);

                    float side = Math.min(availableWidth, availableHeight);

                    float squareX = drawX - (side / 2);
                    float squareY = drawY - (side / 2);

                    iGraphics.fillRectangle(squareX, squareY, side, side);
                    break;

                case Fuego:
                    iGraphics.setColor(0xFFE1050F);
                    float radius = Math.min(availableWidth, availableHeight) / 2;
                    iGraphics.fillHexagon(drawX, drawY, radius);
                    break;
                case Star:
                    iGraphics.setColor(0xFFFF0080);
                    float radiusStar = Math.min(availableWidth, availableHeight) / 2;
                    iGraphics.fillStar(drawX, drawY, radiusStar);
                    break;
                case Stun:
                    iGraphics.setColor(0xFF944D03);
                    float radiusStun = Math.min(availableWidth, availableHeight) / 2;
                    iGraphics.fillOctagon(drawX, drawY, radiusStun);
                    break;
                case Poison:
                    iGraphics.setColor(0xFF00FF00);
                    float radiusPoison = Math.min(availableWidth, availableHeight) / 2;
                    iGraphics.fillCircle(drawX, drawY, radiusPoison);
                    break;
            }


        if (text != null && iFont != null) {
            iGraphics.setColor(textColor);
            float textX = x + (width / 2);
            float textY = y + imageHeight + (textHeight / 2) + (iFont.getSize() / 3);
            iGraphics.drawText(iFont, text, textX, textY);
        }
    }

    /**
     * GETTERS.
     */
    public boolean isTouched(int touchX, int touchY) {
        float left = x;
        float top = y;
        float right = x + width;
        float bottom = y + height;

        return touchX >= left && touchX <= right && touchY >= top && touchY <= bottom;
    }

    // Coste.
    public int getCost() {
        return this.cost;
    }

    // Tipo.
    public TowerType getTipo() {
        return this.tipo;
    }

    /**
     * SETTERS
     */
    // Selección / deselección.
    public void setSelected(boolean selected) {
        this.selected = selected;
        buttonColor = this.selected ? 0xFFD3D3D3 : 0xFFFFFFFF;
    }
}
