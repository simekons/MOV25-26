package com.example.androidengine;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/**
 * AndroidWorker implementa parte de las notificaciones.
 */
public class AndroidWorker extends Worker {

    public static String channelIdInput = "notifications_channel_id";
    public static String titleInput = "title";
    public static String descriptionInput = "description";
    public static String iconInput = "notifications_icon";
    public static String classInput = "class";

    /**
     * CONSTRUCTORA.
     * @param context
     * @param workerParams
     */
    public AndroidWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    /**
     * Método que gestiona la notificación.
     * @return
     */
    @NonNull
    @Override
    public Result doWork() {
        String title = getInputData().getString(titleInput);
        String description = getInputData().getString(descriptionInput);
        String CHANNEL_ID = getInputData().getString(channelIdInput);
        int icon = getInputData().getInt(iconInput,0);
        String nameClass=getInputData().getString(classInput);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());

        Intent intent;
        try {
            Class<?> activityClass = Class.forName(nameClass);
            intent = new Intent(getApplicationContext(), activityClass);
        } catch (ClassNotFoundException e) {
            return Result.failure();
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("FROM_NOTIFICATION", true);

        //if (intent == null){
        //    Log.d("NOTIFICATION", "Worker ejecutado");
        //}
        //else {
        //    Log.d("NOTIFICACION", "Worker va bien");
        //}
        PendingIntent contentIntent = PendingIntent. getActivity(getApplicationContext(), 0, intent,
                PendingIntent. FLAG_IMMUTABLE | PendingIntent. FLAG_UPDATE_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder( getApplicationContext(), CHANNEL_ID)
                .setSmallIcon(icon)
                .setContentTitle( title )
                .setContentText( description )
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setChannelId(CHANNEL_ID);

        getApplicationContext().checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS);
        notificationManager.notify(1, builder.build());

        return Result.success();
    }
}
