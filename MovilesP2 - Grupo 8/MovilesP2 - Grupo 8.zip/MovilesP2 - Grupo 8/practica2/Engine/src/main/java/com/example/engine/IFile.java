package com.example.engine;

public interface IFile {
    byte[] readFile(String path);
}
